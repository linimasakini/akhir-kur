const Spinner = () => `
<div class="spinner">
<div class="ring"></div>
<div class="ring"></div>
<div class="ring"></div>
<div class="ring"></div>
<span class="loading">loading...</span>
</div>
`;

export default Spinner;
