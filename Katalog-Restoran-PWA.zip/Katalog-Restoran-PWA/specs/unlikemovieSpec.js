import FavoriteMovieIdb from '../src/scripts/data/resto-idb';
import * as testFacories from './helper/testFactories';

const addLikeButtonContainer = () => {
  document.body.innerHTML = ' <div id="likeButtonContainer"></div>';
};

describe('Unliking Resto', () => {
  beforeEach(async () => {
    addLikeButtonContainer();
    await FavoriteMovieIdb.putResto({ id: 1 });
  });

  afterEach(async () => {
    await FavoriteMovieIdb.deleteResto(1);
  });

  it('should display unlike widget when the resto has been liked', async () => {
    await testFacories.createLikeButtonPresenterWithResto({ id: 1 });

    expect(document.querySelector('[aria-label="unlike this resto"]')).toBeTruthy();
  });

  it('should not display unlike widget when the resto has been liked', async () => {
    await testFacories.createLikeButtonPresenterWithResto({ id: 1 });

    expect('it should not display unlike widget when the resto has been liked', async () => {
      await testFacories.createLikeButtonPresenterWithResto({ id: 1 });
    });
  });
});
