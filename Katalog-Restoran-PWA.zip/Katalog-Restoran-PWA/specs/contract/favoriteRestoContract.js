const itActsAsFavoriteRestoModel = (FavoriteMovieIdb) => {
  it('should return the movie that has been added', async () => {
    FavoriteMovieIdb.putResto({ id: 1 });
    FavoriteMovieIdb.putResto({ id: 2 });

    expect(await FavoriteMovieIdb.getResto(1)).toEqual({ id: 1 });
    expect(await FavoriteMovieIdb.getResto(2)).toEqual({ id: 2 });
    expect(await FavoriteMovieIdb.getResto(3)).toEqual(undefined);
  });

  it('should refuse a resto from being added if it does not have the correct property', async () => {
    FavoriteMovieIdb.putResto({ aProperty: 'property' });

    expect(await FavoriteMovieIdb.getAllRestos()).toEqual([]);
  });

  it('can return all of the resto that have been added', async () => {
    FavoriteMovieIdb.putResto({ id: 1 });
    FavoriteMovieIdb.putResto({ id: 2 });

    expect(await FavoriteMovieIdb.getAllRestos()).toEqual([{ id: 1 }, { id: 2 }]);
  });

  it('should remove favorite resto', async () => {
    FavoriteMovieIdb.putResto({ id: 1 });
    FavoriteMovieIdb.putResto({ id: 2 });
    FavoriteMovieIdb.putResto({ id: 3 });

    await FavoriteMovieIdb.deleteResto(1);

    expect(await FavoriteMovieIdb.getAllRestos()).toEqual([{ id: 2 }, { id: 3 }]);
  });

  it('should handle request to remove a movie even though the movie has not been added', async () => {
    FavoriteMovieIdb.putResto({ id: 1 });
    FavoriteMovieIdb.putResto({ id: 2 });
    FavoriteMovieIdb.putResto({ id: 3 });

    await FavoriteMovieIdb.deleteResto(4);

    expect(await FavoriteMovieIdb.getAllRestos()).toEqual([{ id: 1 }, { id: 2 }, { id: 3 }]);
  });
};

// eslint-disable-next-line import/prefer-default-export
export { itActsAsFavoriteRestoModel };
