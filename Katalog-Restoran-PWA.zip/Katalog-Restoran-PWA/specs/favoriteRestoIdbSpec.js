import { itActsAsFavoriteRestoModel } from './contract/favoriteRestoContract';
import FavoriteMovieIdb from '../src/scripts/data/resto-idb';

describe('Favorite Resto Id Contract Test Implementation', () => {
  afterEach(async () => {
    (await FavoriteMovieIdb.getAllRestos()).forEach(async (resto) => {
      await FavoriteMovieIdb.deleteResto(resto.id);
    });
  });
  itActsAsFavoriteRestoModel(FavoriteMovieIdb);
});
