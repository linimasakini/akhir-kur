import LikeButtonInitiator from '../../src/scripts/utils/like-button-initiator';
import FavoriteMovieIdb from '../../src/scripts/data/resto-idb';

const createLikeButtonPresenterWithResto = async (restaurant) => {
  await LikeButtonInitiator.init({
    likeButttonContainer: document.querySelector('#likeButtonContainer'),
    favResto: FavoriteMovieIdb,
    data: {
      restaurant,
    },
  });
};

// eslint-disable-next-line import/prefer-default-export
export { createLikeButtonPresenterWithResto };
