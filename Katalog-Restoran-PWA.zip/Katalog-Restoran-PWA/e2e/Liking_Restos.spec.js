Feature('Liking Restos');

Before(({ I }) => {
    I.amOnPage('/#/favorite');
});

Scenario('showing empty liked movies',  ({ I }) => {
    I.seeElement('.list');
    I.see('Empty favorite Resto. Put one, by clicking heart button in the detail page.', '#mcon');
});

Scenario('liking one movie', ({ I }) =>{
    I.see('Tidak ada film untuk ditampilkan', '#mcon');

    I.amOnPage('/');
    I.seeElement('.list_item_thumb');
    I.click(locate('.list_item_thumb').first());
});